from flask import Flask, render_template, request
import numpy as np
import cv2
from keras.models import load_model

app = Flask(__name__)

# Load model
model = load_model("plant_disease.h5")

CLASS_NAMES = [
    'Corn-Common_rust',
    'Potato-Early_blight',
    'Tomato-Bacterial_spot'
]

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/detector', methods=['GET', 'POST'])
def detector():
    prediction = None

    if request.method == 'POST':
        file = request.files['image']

        if file:
            file_bytes = np.frombuffer(file.read(), np.uint8)
            img = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
            img = cv2.resize(img, (256, 256))
            img = img.reshape(1, 256, 256, 3)

            pred = model.predict(img)
            result = CLASS_NAMES[np.argmax(pred)]
            prediction = f"{result.split('-')[0]} leaf with {result.split('-')[1]}"

    return render_template('detector.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
