import streamlit as st
import numpy as np
import cv2
from keras.models import load_model

st.set_page_config(
    page_title="Plant Disease Detection",
    page_icon="🌿",
    layout="centered"
)

# Load model
model = load_model("plant_disease.h5")

CLASS_NAMES = [
    'Corn-Common_rust',
    'Potato-Early_blight',
    'Tomato-Bacterial_spot'
]

# Custom CSS
st.markdown("""
<style>
body {
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
    color: white;
}
.stButton>button {
    background-color: #28a745;
    color: white;
    border-radius: 10px;
    padding: 10px 20px;
}
</style>
""", unsafe_allow_html=True)

st.title("🌱 Plant Disease Detection")
st.write("Upload a plant leaf image to detect disease")

uploaded_file = st.file_uploader("Choose an image", type=["jpg", "png"])

if uploaded_file:
    file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
    image = cv2.imdecode(file_bytes, 1)
    st.image(image, channels="BGR")

    image = cv2.resize(image, (256, 256))
    image = image.reshape(1, 256, 256, 3)

    if st.button("Predict"):
        prediction = model.predict(image)
        result = CLASS_NAMES[np.argmax(prediction)]
        st.success(
            f"This is a {result.split('-')[0]} leaf with {result.split('-')[1]}"
        )

